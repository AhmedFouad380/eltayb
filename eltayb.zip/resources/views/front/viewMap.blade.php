
<iframe src="https://maps.google.com/maps?q={{$data->lat}},{{$data->lng}}&z=15&output=embed&z=11" width="100%" height="370" frameborder="0" style="border:0"></iframe>
